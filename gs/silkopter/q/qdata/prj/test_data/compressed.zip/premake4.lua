math.randomseed(1014)
	
solution 'q'
	
	language 'C++'

	location ( _ACTION )
	
	flags {'Symbols', 'NoMinimalRebuild',  'No64BitChecks', 'NoExceptions', 'NoRTTI' }

	configurations { 'Debug', 'Release' }

	-- Multithreaded compiling
	if _ACTION == 'vs2010' or _ACTION == 'vs2012' then
		buildoptions { '/MP', '/EHsc', '-Zm256' }
	end 
	
	configuration 'Release'
		defines { 'NDEBUG', '_SECURE_SCL=0', '_SECURE_SCL_THROWS=0', '_SCL_SECURE_NO_WARNINGS', '_CRT_SECURE_NO_WARNINGS'}		
		flags{ 'OptimizeSize'}
	
	configuration 'Debug'
		defines { '_SCL_SECURE_NO_WARNINGS', '_CRT_SECURE_NO_WARNINGS' }


	
project 'qbase'
	kind 'Reference'
	location ('../../qbase/prj/'.._ACTION)
	uuid '0E517723-09BC-CF4A-A56F-5FBA2F07CDDF' 

project 'qdata'
	kind 'Reference'
	location ('../../qdata/prj/'.._ACTION)
	uuid 'DC2E582A-3C90-944C-8031-57D82A54E253' 

project 'qmath'
	kind 'Reference'
	location ('../../qmath/prj/'.._ACTION)
	uuid '673E81C6-3CE4-0E4C-AE1E-88553DD3F3AB'

project 'q'
	files { '../src/**','../include/**'}
	if _ACTION == 'xcode4' then	
		excludes 
		{ 
			'../src/video/displays/EGLDisplay.cpp', 
			'../src/video/displays/WGLDisplay.cpp',
		}
	elseif _ACTION == 'vs2010' or _ACTION == 'vs2012' then
		buildexcludes { 
			'../src/video/displays/EAGLView.mm', 
			'../src/video/displays/IOSDisplay.mm',
			'../src/video/displays/IOSDisplay.cpp',
			'../src/video/displays/EGLDisplay.cpp'
		}
	end 
	
	kind 'StaticLib'
	uuid '21F5D54C-9378-564C-9C9B-9F30C1B042BF'
	
	
	includedirs 
	{ 
		'../include/',
		'../../qbase/include/',
		'../../qdata/include/',
		'../../qmath/include/',
		'../../pugixml/src/',
		'../../freetype2/include/',
		'../../../boost/'
	}
	
	if _ACTION == 'xcode4' then
		pchheader 'qstdafx.pch'
	else
		pchheader '../include/QStdAfx.h'
	end

	pchsource '../src/QStdAfx.cpp'

	libdirs 
	{ 
		'../../qbase/lib/' .. _ACTION,
		'../../qdata/lib/' .. _ACTION,
		'../../freetype2/lib/' .. _ACTION,
	}
    
	targetdir ( '../lib/' .. _ACTION )
	
	configuration 'Debug'
		targetname( 'q_lib_d' )
		if _ACTION == 'xcode4' then
			links { 'qbase_lib_d', 'qdata_lib_d', 'freetype_lib_d' }
		elseif _ACTION == 'vs2010' or _ACTION == 'vs2012' then
			links { 'qbase_lib_d', 'qdata_lib_d', 'OpenGL32', 'Glu32', 'freetype_lib_d' }
		end 
		
	configuration 'Release'
		targetname( 'q_lib' )
		if _ACTION == 'xcode4' then
			links { 'qbase_lib', 'qdata_lib', 'freetype_lib' }
		elseif _ACTION == 'vs2010' or _ACTION == 'vs2012' then
			links { 'qbase_lib', 'qdata_lib', 'OpenGL32', 'Glu32', 'freetype_lib' }
		end 
		
project "test"
	files { "../test/*.cpp"}
	
	uuid "B66F2E63-8A36-B34D-90A1-C87C7F28D8A0"
	flags {  }
	 
	if _ACTION == "xcode4" then
		kind "WindowedApp"
		files { "Info.plist" }
		files { "../test/*.mm" }
	else
		kind "ConsoleApp"
	end

	includedirs 
	{ 
		'../include/',
		'../../qbase/include/',
		'../../qdata/include/',
		'../../qmath/include/',
		'../../pugixml/src/', 
		'../../../boost/'
	}
					
	libdirs 
	{ 
		"../lib/" .. _ACTION,
		'../../../boost/stage/lib'
	}	
	
	targetdir ( "build/" .. _ACTION )
	
	xcodebuildsettings 
	{
		["CODE_SIGN_IDENTITY"] = "iPhone Developer: Valeri Vuchov (WDTMDP2J2J)",
		["GCC_SYMBOLS_PRIVATE_EXTERN"] = "YES";	
		["GCC_VERSION"] = "com.apple.compilers.llvm.clang.1_0";
	}
		
	configuration "Release*"
		targetname( "test" )
		links { 
			"q_lib",
		}
		
		if _ACTION == "xcode4" then
			links { "Foundation.framework" }
			links { "uikit.framework" }
			links { "OpenGLES.framework" }
			links { "quartzcore.framework" }
			links { "z" }
		end 
		
				
	configuration "Debug*"
		targetname( "test_d" )
		links { 
			"q_lib_d",
		}
		
		if _ACTION == "xcode4" then
			links { "Foundation.framework" }
			links { "uikit.framework" }
			links { "OpenGLES.framework" }
			links { "quartzcore.framework" }
			links { "z" }
		end 
		